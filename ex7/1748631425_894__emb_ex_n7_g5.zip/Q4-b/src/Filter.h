#ifndef FILTER_H
#define FILTER_H

#include <Arduino.h>

void run_filter();

#endif