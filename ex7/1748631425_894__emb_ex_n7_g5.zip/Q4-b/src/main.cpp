#include <Arduino.h>
#include "Filter.h"

void setup() {
  // put your setup code here, to run once:
  Serial.begin(9600);

  delay(1000);

  unsigned long start = micros();
  run_filter();
  unsigned long end = micros();

  Serial.print("Execution time (microseconds): ");
  Serial.println(end - start);
}

void loop() {
  // put your main code here, to run repeatedly:
}