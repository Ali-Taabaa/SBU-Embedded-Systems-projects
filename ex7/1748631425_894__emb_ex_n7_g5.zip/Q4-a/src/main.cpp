#include <Arduino.h>

#define LED 13
const int dp = 500;

void setup() {
  // put your setup code here, to run once:
  Serial.begin(9600);
  pinMode(LED, OUTPUT);
}

void loop() {
  // put your main code here, to run repeatedly:
  digitalWrite(LED, HIGH);
  Serial.println("LED is On");
  delay(dp);


  digitalWrite(LED, LOW);
  Serial.println("LED is Off");
  delay(dp);
}