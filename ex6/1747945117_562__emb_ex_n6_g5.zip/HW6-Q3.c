extern "C" {
  #include "HW5_Q3.h"
}

#include <Arduino_FreeRTOS.h>
#include <semphr.h>
#include <AccelStepper.h>

#define ECHO_PIN A3
#define TRIG_PIN A2
#define AOUT A0

#define MOTOR_SPEED 100

AccelStepper Motor(AccelStepper::FULL4WIRE, 4, 5, 6, 7);
AccelStepper Fan(AccelStepper::FULL4WIRE, 8, 9, 10, 11);


static SemaphoreHandle_t xGasReadySemaphore;
static SemaphoreHandle_t xDistanceReadySemaphore;

float latestGas = 0;
float latestDistance = 0;

static unsigned long DistanceTimer = 0;

int V_PPM_C(int Sensor_Value) {
  const float b = 4.22;
  const float a = 0.0005;
  float Volt = ((float)Sensor_Value / 1024) * 5;
  float ppm = (Volt - b) / a;
  return (int)ppm;
}


void ReadGasTask(void *pvParameters) {
  pinMode(AOUT, INPUT);

  for (;;) {
    int sensorValue = analogRead(AOUT);
    latestGas = V_PPM_C(sensorValue);

    xSemaphoreGive(xGasReadySemaphore);

    vTaskDelay(pdMS_TO_TICKS(200)); 
  }
}

void ReadDistanceTask(void *pvParameters) {
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);

  for (;;) {
    if (millis() - DistanceTimer > 500) {
      DistanceTimer = millis();

      digitalWrite(TRIG_PIN, LOW);
      delayMicroseconds(2);
      digitalWrite(TRIG_PIN, HIGH);
      delayMicroseconds(10);
      digitalWrite(TRIG_PIN, LOW);

      long duration = pulseIn(ECHO_PIN, HIGH, 30000); 
      if (duration > 0) {
        latestDistance = duration / 58.0;
      } else {
        latestDistance = -1; 
      }

      xSemaphoreGive(xDistanceReadySemaphore);
    }

    vTaskDelay(pdMS_TO_TICKS(50)); 
  }
}


void DecisionTask(void *pvParameters) {
  for (;;) {
        xSemaphoreTake(xGasReadySemaphore, portMAX_DELAY);
        xSemaphoreTake(xDistanceReadySemaphore, portMAX_DELAY);

        HW5_Q3_U.ppm = latestGas;
        HW5_Q3_U.dist = latestDistance;


        HW5_Q3_step();
        vTaskDelay(pdMS_TO_TICKS(50)); 
  }
}

void ControlMotorTask(void *pvParameters) {
  for (;;) {
    Motor.setSpeed(MOTOR_SPEED * HW5_Q3_Y.Motor); 
    Motor.runSpeed();
    vTaskDelay(pdMS_TO_TICKS(10));
  }
}

void ControlFanTask(void *pvParameters) {
  for (;;) {
    int fanSpeed = map(latestGas, 0, 800, 0, 2000);
    Fan.setSpeed(fanSpeed * HW5_Q3_Y.Fan);
    Fan.runSpeed();
    vTaskDelay(pdMS_TO_TICKS(10));
  }
}

void setup() {
  Serial.begin(9600);
  HW5_Q3_initialize();

  Motor.setMaxSpeed(999999);
  Motor.setAcceleration(999999);
  Fan.setMaxSpeed(999999);
  Fan.setAcceleration(999999);

  xGasReadySemaphore = xSemaphoreCreateBinary();
  xDistanceReadySemaphore = xSemaphoreCreateBinary();

  xTaskCreate(ReadGasTask, "ReadGas", 64, NULL, 2, NULL);
  xTaskCreate(ReadDistanceTask, "ReadDistance", 64, NULL, 2, NULL);
  xTaskCreate(DecisionTask, "Decision", 64, NULL, 3, NULL);
  xTaskCreate(ControlMotorTask, "Motor", 64, NULL, 1, NULL);
  xTaskCreate(ControlFanTask, "Fan", 64, NULL, 1, NULL);
}

void loop() {}
