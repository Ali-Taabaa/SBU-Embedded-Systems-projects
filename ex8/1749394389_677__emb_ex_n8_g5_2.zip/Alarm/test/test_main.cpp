#include <unity.h>

extern "C" {
    #include "Q3.h"
}

void run_steps(){
    Q3_step();
    Q3_step();
}
// functions for each input respectively
void without_input(){
    run_steps();
    TEST_ASSERT_EQUAL(0, Q3_Y.on);
    TEST_ASSERT_EQUAL(0, Q3_Y.A1);
    TEST_ASSERT_EQUAL(0, Q3_Y.mode);
    TEST_ASSERT_EQUAL(0, Q3_Y.off);
    TEST_ASSERT_EQUAL(0, Q3_Y.A2);
    TEST_ASSERT_EQUAL(1, Q3_Y.shut);
    TEST_ASSERT_EQUAL(0, Q3_Y.op);
    TEST_ASSERT_EQUAL(0, Q3_Y.vol);
}


void Start(){
    Q3_U.start = 1;
    run_steps();
    TEST_ASSERT_EQUAL(0, Q3_Y.on);
    TEST_ASSERT_EQUAL(1, Q3_Y.A1);
    TEST_ASSERT_EQUAL(1, Q3_Y.mode);
    TEST_ASSERT_EQUAL(1, Q3_Y.off);
    TEST_ASSERT_EQUAL(0, Q3_Y.A2);
    TEST_ASSERT_EQUAL(0, Q3_Y.shut);
    TEST_ASSERT_EQUAL(1, Q3_Y.op);
    TEST_ASSERT_EQUAL(1, Q3_Y.vol);
    Q3_U.start = 0;
}


void t_on(){
    Q3_U.t_on = 1;
    run_steps();
    TEST_ASSERT_EQUAL(1, Q3_Y.on);
    TEST_ASSERT_EQUAL(1, Q3_Y.A1);
    TEST_ASSERT_EQUAL(1, Q3_Y.mode);
    TEST_ASSERT_EQUAL(0, Q3_Y.off);
    TEST_ASSERT_EQUAL(0, Q3_Y.A2);
    TEST_ASSERT_EQUAL(0, Q3_Y.shut);
    TEST_ASSERT_EQUAL(1, Q3_Y.op);
    TEST_ASSERT_EQUAL(1, Q3_Y.vol);
    Q3_U.t_on = 0;
}


void inc(){
    Q3_U.inc = 1;
    run_steps();
    TEST_ASSERT_EQUAL(1, Q3_Y.on);
    TEST_ASSERT_EQUAL(0, Q3_Y.A1);
    TEST_ASSERT_EQUAL(1, Q3_Y.mode);
    TEST_ASSERT_EQUAL(0, Q3_Y.off);
    TEST_ASSERT_EQUAL(1, Q3_Y.A2);
    TEST_ASSERT_EQUAL(0, Q3_Y.shut);
    TEST_ASSERT_EQUAL(1, Q3_Y.op);
    TEST_ASSERT_EQUAL(1, Q3_Y.vol);
    Q3_U.inc = 0;
}


void dec(){
    Q3_U.dec = 1;
    run_steps();
    TEST_ASSERT_EQUAL(1, Q3_Y.on);
    TEST_ASSERT_EQUAL(1, Q3_Y.A1);
    TEST_ASSERT_EQUAL(1, Q3_Y.mode);
    TEST_ASSERT_EQUAL(0, Q3_Y.off);
    TEST_ASSERT_EQUAL(0, Q3_Y.A2);
    TEST_ASSERT_EQUAL(0, Q3_Y.shut);
    TEST_ASSERT_EQUAL(1, Q3_Y.op);
    TEST_ASSERT_EQUAL(1, Q3_Y.vol);
    Q3_U.dec = 0;
}


void stop(){
    Q3_U.stop = 1;
    run_steps();
    TEST_ASSERT_EQUAL(0, Q3_Y.on);
    TEST_ASSERT_EQUAL(0, Q3_Y.A1);
    TEST_ASSERT_EQUAL(0, Q3_Y.mode);
    TEST_ASSERT_EQUAL(0, Q3_Y.off);
    TEST_ASSERT_EQUAL(0, Q3_Y.A2);
    TEST_ASSERT_EQUAL(1, Q3_Y.shut);
    TEST_ASSERT_EQUAL(0, Q3_Y.op);
    TEST_ASSERT_EQUAL(0, Q3_Y.vol);
}

int main(int argc, char **argv) {
    UNITY_BEGIN();

    // run tests
    RUN_TEST(without_input);
    RUN_TEST(Start);
    RUN_TEST(t_on);
    RUN_TEST(inc);
    RUN_TEST(dec);
    RUN_TEST(stop);

    UNITY_END();

    return 0;
}