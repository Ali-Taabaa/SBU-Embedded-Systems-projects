/*
 * File: Q3.h
 *
 * Code generated for Simulink model 'Q3'.
 *
 * Model version                  : 1.0
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Sun Jun  8 00:41:37 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef Q3_h_
#define Q3_h_
#ifndef Q3_COMMON_INCLUDES_
#define Q3_COMMON_INCLUDES_
#include "rtwtypes.h"
// #include "rtw_continuous.h"
// #include "rtw_solver.h"
#endif                                 /* Q3_COMMON_INCLUDES_ */

#include "Q3_types.h"
#include <stddef.h>

/* Macros for accessing real-time model data structure */
#ifndef rtmGetErrorStatus
#define rtmGetErrorStatus(rtm)         ((rtm)->errorStatus)
#endif

#ifndef rtmSetErrorStatus
#define rtmSetErrorStatus(rtm, val)    ((rtm)->errorStatus = (val))
#endif

/* Block states (default storage) for system '<Root>' */
typedef struct {
  uint8_T is_active_c3_Q3;             /* '<Root>/Alarm' */
  uint8_T is_c3_Q3;                    /* '<Root>/Alarm' */
  uint8_T is_Mode;                     /* '<Root>/Alarm' */
  uint8_T is_Vol;                      /* '<Root>/Alarm' */
} DW_Q3_T;

/* External inputs (root inport signals with default storage) */
typedef struct {
  real_T start;                        /* '<Root>/start' */
  real_T t_on;                         /* '<Root>/t_on' */
  real_T inc;                          /* '<Root>/inc' */
  real_T dec;                          /* '<Root>/dec' */
  real_T stop;                         /* '<Root>/stop' */
  real_T t_off;                        /* '<Root>/t_off' */
} ExtU_Q3_T;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  real_T on;                           /* '<Root>/on' */
  real_T A1;                           /* '<Root>/A1' */
  real_T mode;                         /* '<Root>/mode' */
  real_T off;                          /* '<Root>/off' */
  real_T A2;                           /* '<Root>/A2' */
  real_T shut;                         /* '<Root>/shut' */
  real_T op;                           /* '<Root>/op' */
  real_T vol;                          /* '<Root>/vol' */
} ExtY_Q3_T;

/* Real-time Model Data Structure */
struct tag_RTM_Q3_T {
  const char_T * volatile errorStatus;
};

/* Block states (default storage) */
extern DW_Q3_T Q3_DW;

/* External inputs (root inport signals with default storage) */
extern ExtU_Q3_T Q3_U;

/* External outputs (root outports fed by signals with default storage) */
extern ExtY_Q3_T Q3_Y;

/* Model entry point functions */
extern void Q3_initialize(void);
extern void Q3_step(void);
extern void Q3_terminate(void);

/* Real-time Model object */
extern RT_MODEL_Q3_T *const Q3_M;
extern volatile boolean_T stopRequested;
extern volatile boolean_T runModel;

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Use the MATLAB hilite_system command to trace the generated code back
 * to the model.  For example,
 *
 * hilite_system('<S3>')    - opens system 3
 * hilite_system('<S3>/Kp') - opens and selects block Kp which resides in S3
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'Q3'
 * '<S1>'   : 'Q3/Alarm'
 */
#endif                                 /* Q3_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
