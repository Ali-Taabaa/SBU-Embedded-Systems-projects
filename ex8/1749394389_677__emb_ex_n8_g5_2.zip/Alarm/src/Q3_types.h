/*
 * File: Q3_types.h
 *
 * Code generated for Simulink model 'Q3'.
 *
 * Model version                  : 1.0
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Sun Jun  8 00:41:37 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef Q3_types_h_
#define Q3_types_h_

/* Forward declaration for rtModel */
typedef struct tag_RTM_Q3_T RT_MODEL_Q3_T;

#endif                                 /* Q3_types_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
