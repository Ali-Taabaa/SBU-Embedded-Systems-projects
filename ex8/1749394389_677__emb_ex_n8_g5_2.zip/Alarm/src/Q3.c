/*
 * File: Q3.c
 *
 * Code generated for Simulink model 'Q3'.
 *
 * Model version                  : 1.0
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Sun Jun  8 00:41:37 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#include "Q3.h"
#include "rtwtypes.h"

/* Named constants for Chart: '<Root>/Alarm' */
#define Q3_IN_NO_ACTIVE_CHILD          ((uint8_T)0U)
#define Q3_IN_Off                      ((uint8_T)1U)
#define Q3_IN_On                       ((uint8_T)2U)
#define Q3_IN_Op                       ((uint8_T)1U)
#define Q3_IN_Shut                     ((uint8_T)2U)
#define Q3_IN_a1                       ((uint8_T)1U)
#define Q3_IN_a2                       ((uint8_T)2U)

/* Block states (default storage) */
DW_Q3_T Q3_DW;

/* External inputs (root inport signals with default storage) */
ExtU_Q3_T Q3_U;

/* External outputs (root outports fed by signals with default storage) */
ExtY_Q3_T Q3_Y;

/* Real-time model */
static RT_MODEL_Q3_T Q3_M_;
RT_MODEL_Q3_T *const Q3_M = &Q3_M_;

/* Model step function */
void Q3_step(void)
{
  /* Chart: '<Root>/Alarm' incorporates:
   *  Inport: '<Root>/dec'
   *  Inport: '<Root>/inc'
   *  Inport: '<Root>/start'
   *  Inport: '<Root>/stop'
   *  Inport: '<Root>/t_off'
   *  Inport: '<Root>/t_on'
   */
  if (Q3_DW.is_active_c3_Q3 == 0U) {
    Q3_DW.is_active_c3_Q3 = 1U;
    Q3_DW.is_c3_Q3 = Q3_IN_Shut;
  } else if (Q3_DW.is_c3_Q3 == Q3_IN_Op) {
    if (Q3_U.stop == 1.0) {
      switch (Q3_DW.is_Vol) {
       case Q3_IN_a1:
        /* Outport: '<Root>/A1' */
        Q3_Y.A1 = 0.0;
        Q3_DW.is_Vol = Q3_IN_NO_ACTIVE_CHILD;
        break;

       case Q3_IN_a2:
        /* Outport: '<Root>/A2' */
        Q3_Y.A2 = 0.0;
        Q3_DW.is_Vol = Q3_IN_NO_ACTIVE_CHILD;
        break;
      }

      /* Outport: '<Root>/vol' */
      Q3_Y.vol = 0.0;
      switch (Q3_DW.is_Mode) {
       case Q3_IN_Off:
        /* Outport: '<Root>/off' */
        Q3_Y.off = 0.0;
        Q3_DW.is_Mode = Q3_IN_NO_ACTIVE_CHILD;
        break;

       case Q3_IN_On:
        /* Outport: '<Root>/on' */
        Q3_Y.on = 0.0;
        Q3_DW.is_Mode = Q3_IN_NO_ACTIVE_CHILD;
        break;
      }

      /* Outport: '<Root>/mode' */
      Q3_Y.mode = 0.0;

      /* Outport: '<Root>/op' */
      Q3_Y.op = 0.0;
      Q3_DW.is_c3_Q3 = Q3_IN_Shut;
    } else {
      /* Outport: '<Root>/op' */
      Q3_Y.op = 1.0;

      /* Outport: '<Root>/mode' */
      Q3_Y.mode = 1.0;
      if (Q3_DW.is_Mode == Q3_IN_Off) {
        if (Q3_U.t_on == 1.0) {
          /* Outport: '<Root>/off' */
          Q3_Y.off = 0.0;
          Q3_DW.is_Mode = Q3_IN_On;
        } else {
          /* Outport: '<Root>/off' */
          Q3_Y.off = 1.0;
        }

        /* case IN_On: */
      } else if (Q3_U.t_off == 1.0) {
        /* Outport: '<Root>/on' */
        Q3_Y.on = 0.0;
        Q3_DW.is_Mode = Q3_IN_Off;
      } else {
        /* Outport: '<Root>/on' */
        Q3_Y.on = 1.0;
      }

      /* Outport: '<Root>/vol' incorporates:
       *  Inport: '<Root>/t_off'
       *  Inport: '<Root>/t_on'
       */
      Q3_Y.vol = 1.0;
      if (Q3_DW.is_Vol == Q3_IN_a1) {
        if (Q3_U.inc == 1.0) {
          /* Outport: '<Root>/A1' */
          Q3_Y.A1 = 0.0;
          Q3_DW.is_Vol = Q3_IN_a2;
        } else {
          /* Outport: '<Root>/A1' */
          Q3_Y.A1 = 1.0;
        }

        /* case IN_a2: */
      } else if (Q3_U.dec == 1.0) {
        /* Outport: '<Root>/A2' */
        Q3_Y.A2 = 0.0;
        Q3_DW.is_Vol = Q3_IN_a1;
      } else {
        /* Outport: '<Root>/A2' */
        Q3_Y.A2 = 1.0;
      }
    }

    /* case IN_Shut: */
  } else if (Q3_U.start == 1.0) {
    /* Outport: '<Root>/shut' */
    Q3_Y.shut = 0.0;
    Q3_DW.is_c3_Q3 = Q3_IN_Op;
    Q3_DW.is_Mode = Q3_IN_Off;
    Q3_DW.is_Vol = Q3_IN_a1;
  } else if (Q3_U.t_on == 1.0) {
    /* Outport: '<Root>/shut' */
    Q3_Y.shut = 0.0;
    Q3_DW.is_c3_Q3 = Q3_IN_Op;
    Q3_DW.is_Mode = Q3_IN_On;
    Q3_DW.is_Vol = Q3_IN_a1;
  } else {
    /* Outport: '<Root>/shut' */
    Q3_Y.shut = 1.0;
  }

  /* End of Chart: '<Root>/Alarm' */
}

/* Model initialize function */
void Q3_initialize(void)
{
  /* (no initialization code required) */
}

/* Model terminate function */
void Q3_terminate(void)
{
  /* (no terminate code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
