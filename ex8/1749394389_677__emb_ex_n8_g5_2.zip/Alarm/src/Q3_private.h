/*
 * File: Q3_private.h
 *
 * Code generated for Simulink model 'Q3'.
 *
 * Model version                  : 1.0
 * Simulink Coder version         : 24.1 (R2024a) 19-Nov-2023
 * C/C++ source code generated on : Sun Jun  8 00:41:37 2025
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: Atmel->AVR
 * Code generation objectives: Unspecified
 * Validation result: Not run
 */

#ifndef Q3_private_h_
#define Q3_private_h_
#include "rtwtypes.h"
#include "Q3_types.h"
// #include "rtw_continuous.h"
// #include "rtw_solver.h"
#endif                                 /* Q3_private_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */
