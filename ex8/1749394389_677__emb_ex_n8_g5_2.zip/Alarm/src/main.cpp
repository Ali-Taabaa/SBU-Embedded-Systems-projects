#include <Arduino.h>

// extern "C" {
//   #include "Q3.h"
// }


#define Pstart A0
#define Pt_on  A1
#define Pinc   A2
#define Pdec   A3
#define Pstop  A4
#define Pt_off A5


#define Pon   6
#define PA1   7
#define Pmode 8
#define Poff  9
#define PA2   10
#define Pshut 11
#define Pop   12
#define Pvol  13




void setup() {
  // put your setup code here, to run once:

  pinMode(Pstart, INPUT);
  pinMode(Pt_on, INPUT);
  pinMode(Pinc, INPUT);
  pinMode(Pdec, INPUT);
  pinMode(Pstop, INPUT);
  pinMode(Pt_off, INPUT);

  pinMode(Pon, OUTPUT);
  pinMode(PA1, OUTPUT);
  pinMode(Pmode, OUTPUT);
  pinMode(Poff, OUTPUT);
  pinMode(PA2, OUTPUT);
  pinMode(Pshut, OUTPUT);
  pinMode(Pop, OUTPUT);
  pinMode(Pvol, OUTPUT);

}

void loop() {
  // put your main code here, to run repeatedly:

  Q3_U.start = digitalRead(Pstart);
  Q3_U.t_on = digitalRead(Pt_on);
  Q3_U.inc = digitalRead(Pinc);
  Q3_U.dec = digitalRead(Pdec);
  Q3_U.stop = digitalRead(Pstop);
  Q3_U.t_off = digitalRead(Pt_off);

  Q3_step();

  digitalWrite(Pon, Q3_Y.on);
  digitalWrite(PA1, Q3_Y.A1);
  digitalWrite(PA2, Q3_Y.A2);
  digitalWrite(Pmode, Q3_Y.mode);
  digitalWrite(Poff, Q3_Y.off);
  digitalWrite(Pshut, Q3_Y.shut);
  digitalWrite(Pop, Q3_Y.op);
  digitalWrite(Pvol, Q3_Y.vol);
}
