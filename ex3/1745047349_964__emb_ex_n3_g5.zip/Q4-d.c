#include <stdio.h>
#include <stdbool.h>
#include <windows.h>

// test output for functions 
#define test_output 1

typedef struct CircularBuffer{
    int* data;
    int head;
    int tail;
    int count;
    int size;
} CircularBuffer;

void initBuffer(CircularBuffer* buf, int* array, int size) {
    buf->data = array;
    buf->head = 0;
    buf->tail = 0;
    buf->count = 0;
    buf->size = size;
}

bool push(CircularBuffer* buf, int val) {
    if (buf->count == buf->size) {
        printf("Buffer overflow!\n");
        return false;
    }
    buf->data[buf->tail] = val;
    buf->tail = (buf->tail + 1) % buf->size;
    buf->count++;
    return true;
}

bool pop(CircularBuffer* buf, int* val) {
    if (buf->count == 0) {
        printf("Buffer underflow!\n");
        return false;
    }
    *val = buf->data[buf->head];
    buf->head = (buf->head + 1) % buf->size;
    buf->count--;
    return true;
}

int a_data[2], b_data[4], c_data[4], d_data[2], e_data[2];
CircularBuffer a_buf, b_buf, c_buf, d_buf, e_buf;

void initAllBuffers() {
    initBuffer(&a_buf, a_data, 2);
    initBuffer(&b_buf, b_data, 4);
    initBuffer(&c_buf, c_data, 4);
    initBuffer(&d_buf, d_data, 2);
    initBuffer(&e_buf, e_data, 2);
}

// initializing Buffer Tokens
void initialize_buffer_Tokens() {
    push(&c_buf, test_output);
    push(&c_buf, test_output);
    push(&c_buf, test_output);
    push(&c_buf, test_output);

    push(&d_buf, test_output);
    push(&d_buf, test_output);
}

/************* Functions ***********/
void P1(int c1, int c2, int c3, int c4, int d1, int d2, int* a1, int* a2) {
    *a1 = test_output;
    *a2 = test_output;
    printf("P1 executed\n");
}

void P2(int a, int* b1, int* b2) {
    *b1 = test_output;
    *b2 = test_output;
    printf("P2 executed\n");
}

void P3(int b1, int b2, int b3, int b4, int* c1, int* c2, int* c3, int* c4, int* e1, int* e2) {
    *c1 = test_output;
    *c2 = test_output;
    *c3 = test_output;
    *c4 = test_output;
    *e1 = test_output;
    *e2 = test_output;
    printf("P3 executed\n");
}

void P4(int e, int* d) {
    *d = test_output;
    printf("P4 executed\n");
}

/* main Function*/
int main() {

    initAllBuffers();
    initialize_buffer_Tokens();

    while (1) {

        printf("----- Iteration Started -----\n");
        // P1
        int c1, c2, c3, c4, d1, d2;
        pop(&c_buf, &c1);
        pop(&c_buf, &c2);
        pop(&c_buf, &c3);
        pop(&c_buf, &c4);
        pop(&d_buf, &d1);
        pop(&d_buf, &d2);
        int a1, a2;
        P1(c1, c2, c3, c4, d1, d2, &a1, &a2);
        Sleep(1000);
        push(&a_buf, a1);
        push(&a_buf, a2);

        // P2
        for (int i = 0; i < 2; i++) {
            int a;
            pop(&a_buf, &a);
            int b1, b2;
            P2(a, &b1, &b2);
            Sleep(1000);
            push(&b_buf, b1);
            push(&b_buf, b2);
        }

        // P3
        int b1, b2, b3, b4; 
        pop(&b_buf, &b1);
        pop(&b_buf, &b2);
        pop(&b_buf, &b3);
        pop(&b_buf, &b4);
        int e1, e2;
        P3(b1, b2, b3, b4, &c1, &c2, &c3, &c4, &e1, &e2);
        Sleep(1000);
        push(&c_buf, c1);
        push(&c_buf, c2);
        push(&c_buf, c3);
        push(&c_buf, c4);
        push(&e_buf, e1);
        push(&e_buf, e2);

        // P4
        for (int i = 0; i < 2; i++) {
            int e; 
            pop(&e_buf, &e);
            int d;
            P4(e, &d);
            Sleep(1000);
            push(&d_buf, d);
        }
        printf("----- Iteration Ended -----\n");
    }
}